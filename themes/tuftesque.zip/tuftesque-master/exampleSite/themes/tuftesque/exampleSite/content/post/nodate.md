+++
title = "Hide Date"
date = "2015-05-15"
hideDate = true
hideReadTime = true

+++

Here is an example post where the date set, but hidden from display.  
Moreover, the reading time is also hidden.

